"""Soup training-job queue."""
