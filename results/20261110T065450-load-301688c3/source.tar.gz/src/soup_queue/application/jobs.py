from typing import Protocol

from soup_queue.domain.jobs import TrainingSpec
from soup_queue.infrastructure.models import Job
from soup_queue.infrastructure.repository import JobRepository


class Wakeup(Protocol):
    async def publish(self) -> None: ...


class JobService:
    def __init__(self, repository: JobRepository, wakeup: Wakeup) -> None:
        self.repository = repository
        self.wakeup = wakeup

    async def create(self, key: str, spec: TrainingSpec) -> tuple[Job, bool]:
        job, created = await self.repository.create(key, spec)
        if created:
            # The repository has committed. Notifications are only a latency optimization.
            await self.wakeup.publish()
        return job, created
