import asyncio
import logging
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Annotated
from uuid import UUID, uuid4

from fastapi import Depends, FastAPI, Header, Query, Request, Response
from fastapi.responses import JSONResponse
from redis.exceptions import RedisError
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from soup_queue.api.schemas import JobPage, JobResponse
from soup_queue.application.jobs import JobService
from soup_queue.config import Settings
from soup_queue.domain.jobs import (
    IdempotencyConflict,
    InvalidCursor,
    JobNotFound,
    JobStatus,
    TerminalConflict,
    TrainingSpec,
)
from soup_queue.infrastructure.database import make_engine, make_sessions
from soup_queue.infrastructure.notifications import RedisWakeup
from soup_queue.infrastructure.repository import JobRepository

logger = logging.getLogger(__name__)


def service(request: Request) -> JobService:
    value: JobService = request.app.state.service
    return value


Service = Annotated[JobService, Depends(service)]


def create_app(settings: Settings | None = None) -> FastAPI:
    config = settings or Settings()

    @asynccontextmanager
    async def lifespan(application: FastAPI) -> AsyncIterator[None]:
        engine = make_engine(config)
        wakeup = RedisWakeup(config.redis_url, config.redis_channel)
        application.state.engine = engine
        application.state.wakeup = wakeup
        application.state.service = JobService(JobRepository(make_sessions(engine), config), wakeup)
        try:
            yield
        finally:
            await wakeup.close()
            await engine.dispose()

    application = FastAPI(
        title="Soup Training Queue",
        version="0.1.0",
        lifespan=lifespan,
        description="Async job queue with idempotent creation, fenced leases, and atomic effects.",
    )

    @application.middleware("http")
    async def request_context(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        request_id = str(uuid4())
        request.state.request_id = request_id
        start = time.monotonic()
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        logger.info(
            "request id=%s method=%s status=%s duration_ms=%.2f",
            request_id,
            request.method,
            response.status_code,
            (time.monotonic() - start) * 1000,
        )
        return response

    async def domain_error(request: Request, exc: Exception) -> JSONResponse:
        code = (
            404 if isinstance(exc, JobNotFound) else 400 if isinstance(exc, InvalidCursor) else 409
        )
        detail = "Job not found" if isinstance(exc, JobNotFound) else str(exc)
        return JSONResponse(
            status_code=code, content={"detail": detail, "request_id": request.state.request_id}
        )

    for error_type in (JobNotFound, InvalidCursor, IdempotencyConflict, TerminalConflict):
        application.add_exception_handler(error_type, domain_error)

    @application.exception_handler(SQLAlchemyError)
    async def database_error(request: Request, exc: SQLAlchemyError) -> JSONResponse:
        logger.error("database_unavailable request_id=%s", request.state.request_id, exc_info=exc)
        return JSONResponse(
            status_code=503,
            headers={"Retry-After": "1"},
            content={
                "detail": "Database temporarily unavailable",
                "request_id": request.state.request_id,
            },
        )

    @application.get("/health/live", tags=["health"])
    async def live() -> dict[str, str]:
        return {"status": "ok"}

    @application.get("/health/ready", tags=["health"])
    async def ready(request: Request) -> JSONResponse:
        try:
            async with asyncio.timeout(2):
                async with request.app.state.engine.connect() as connection:
                    await connection.execute(text("SELECT 1 FROM jobs LIMIT 1"))
        except (SQLAlchemyError, TimeoutError, OSError):
            return JSONResponse(
                status_code=503, content={"status": "unavailable", "database": "down"}
            )
        redis_status = "up"
        try:
            async with asyncio.timeout(0.25):
                await request.app.state.wakeup.redis.ping()
        except (RedisError, TimeoutError, OSError):
            redis_status = "down"
        return JSONResponse(
            content={
                "status": "ok" if redis_status == "up" else "degraded",
                "database": "up",
                "redis": redis_status,
            }
        )

    @application.post(
        "/v1/jobs",
        response_model=JobResponse,
        status_code=201,
        tags=["jobs"],
        responses={
            200: {"description": "Idempotent replay"},
            409: {"description": "Key reused with different payload"},
        },
    )
    async def create_job(
        payload: TrainingSpec,
        response: Response,
        jobs: Service,
        idempotency_key: Annotated[str, Header(min_length=1, max_length=200, pattern=r"^[!-~]+$")],
    ) -> JobResponse:
        job, created = await jobs.create(idempotency_key, payload)
        response.status_code = 201 if created else 200
        response.headers["Location"] = f"/v1/jobs/{job.id}"
        response.headers["Idempotency-Replayed"] = str(not created).lower()
        return JobResponse.model_validate(job)

    @application.get("/v1/jobs", response_model=JobPage, tags=["jobs"])
    async def list_jobs(
        jobs: Service,
        limit: Annotated[int, Query(ge=1, le=100)] = 50,
        cursor: Annotated[str | None, Query(max_length=1024)] = None,
        status: JobStatus | None = None,
    ) -> JobPage:
        rows, next_cursor = await jobs.repository.list(limit, cursor, status)
        return JobPage(
            items=[JobResponse.model_validate(row) for row in rows], next_cursor=next_cursor
        )

    @application.get("/v1/jobs/{job_id}", response_model=JobResponse, tags=["jobs"])
    async def get_job(job_id: UUID, jobs: Service) -> JobResponse:
        return JobResponse.model_validate(await jobs.repository.get(job_id))

    @application.post(
        "/v1/jobs/{job_id}/cancel",
        response_model=JobResponse,
        tags=["jobs"],
        responses={409: {"description": "Job already succeeded or failed"}},
    )
    async def cancel_job(job_id: UUID, jobs: Service) -> JobResponse:
        return JobResponse.model_validate(await jobs.repository.cancel(job_id))

    return application


app = create_app()
